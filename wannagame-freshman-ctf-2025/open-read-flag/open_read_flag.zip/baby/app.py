# safe_file_app.py
import re
import uuid
from flask import Flask, request, render_template_string, abort
import os

app = Flask(__name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__)) +'/document' # current directory

FLAG = "flag{this_is_a_test_flag}"  
flagPath = "b9cdb7c9-7493-4e82-9319-1a2ce73d8fa1"
with open(flagPath, "w") as f:
    f.write(FLAG)
print(f"Created file: {flagPath} with the flag inside.")

@app.route('/')
def home():
    return '''
        <h1>Read a file</h1>
        <form method="GET" action="/read">
            <input type="text" name="file" placeholder="Enter file name">
            <input type="submit" value="Read">
        </form>
    '''

@app.route('/read')
def read_file():
    filename = request.args.get('file', '')
    uuid_pattern = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}"
    matches = re.findall(uuid_pattern, filename)
    if matches:
        if matches[0] == flagPath : 
            return f"Error : Sorry this is protected !"
    if ".." in filename  : 
        return f"Error : Why the .. here ???"
    try:
        filepath = os.path.join(BASE_DIR, filename)
        with open(filepath, "r") as f:
            content = f.read()
    except Exception as e:
        return f"Error: {e}"
    
    return render_template_string('''
        <h1>File: {{ filename }}</h1>
        <pre>{{ content }}</pre>
        <a href="/">Go back</a>
    ''', filename=filename, content=content)

if __name__ == "__main__":
    app.run(host="0.0.0.0",port=5000, debug=False)
