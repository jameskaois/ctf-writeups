const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const expressLayouts = require('express-ejs-layouts');  
const cookieParser = require('cookie-parser');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

const DATABASE = 'dashboard.db';
const db = new sqlite3.Database(DATABASE);

function initDb() {
     db.run("PRAGMA foreign_keys = ON;");
    db.serialize(() => {
        db.run(`
            CREATE TABLE IF NOT EXISTS User (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        `);
        
        // Create Action table with foreign key constraint
        db.run(`
            CREATE TABLE IF NOT EXISTS Action (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                action_name TEXT DEFAULT 'accepted',
                reason TEXT DEFAULT 'No reason provided',
                FOREIGN KEY (username) REFERENCES User (username) ON DELETE CASCADE
            )
        `);
    });
}

function admin_action(username, action_name='accepted', reason='No reason provided') {
    db.run('INSERT INTO Action (username, action_name, reason) VALUES (?, ?, ?)', [username, action_name, reason]);
}

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'layout');
app.use(cookieParser(crypto.randomBytes(64).toString('hex')));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use((req, res, next) => {
    res.locals.user = req.signedCookies.username || null;
    next();
});



function loginRequired(req, res, next) {
    if (!req.signedCookies.username) {
        return res.redirect('/login');
    }
    next();
}

app.get('/', (req, res) => {
    if (req.signedCookies.username) {
        return res.redirect('/dashboard');
    }
    res.render('index');
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', (req, res) => {
    const { username, password, confirm_password } = req.body;
    
    if (!username || !password) {
        return res.render('register', { error: 'Tên đăng nhập và mật khẩu là bắt buộc.' });
    }

    if (password !== confirm_password) {
        return res.render('register', { error: 'Mật khẩu không khớp.' });
    }

    db.run('INSERT INTO User (username, password) VALUES (?, ?)', [username, password], function(err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
                return res.render('register', { error: 'Tên đăng nhập đã tồn tại.' });
            }
            return res.render('register', { error: 'Lỗi đăng ký.' });
        }
        // How annoyed admin is at new user
        admin_action(username, 'banned', 'Thích thế');
        res.render('login', { success: 'Đăng ký thành công! Vui lòng đăng nhập.' });
    });
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    db.get('SELECT * FROM User WHERE username = ?', [username], (err, user) => {
        if (err) {
            return res.render('login', { error: 'Lỗi đăng nhập.' });
        }
        
        // Simple password check (no bcrypt as requested)
        if (user && user.password === password) {
            res.cookie('username', username, { signed: true });
            return res.redirect('/dashboard');
        } else {
            return res.render('login', { error: 'Tên đăng nhập hoặc mật khẩu không đúng.' });
        }
    });
});

app.get('/logout', (req, res) => {
    res.clearCookie('username');
    res.redirect('/');
});

app.get('/dashboard', loginRequired, (req, res) => {
    const username = req.signedCookies.username;
    
    // Get user actions
    db.all('SELECT * FROM Action WHERE username = ?', [username], (err, actions) => {
        if (err) {
            actions = [];
        }
        res.render('dashboard', { username, actions, layout: false });
    });
});

app.get('/change_password', loginRequired, (req, res) => {
    res.render('change_password');
});

app.post('/change_password', loginRequired, (req, res) => {
    const { current_password, new_password, confirm_password } = req.body;
    const username = req.signedCookies.username;
    
    // Simplified - no current password verification as requested
    if (new_password !== confirm_password) {
        return res.render('change_password', { error: 'Mật khẩu mới không khớp.' });
    }
    
    // Update password (plain text as requested)
    db.run('UPDATE User SET password = ? WHERE username = ?', [new_password, username], (err) => {
        if (err) {
            return res.render('change_password', { error: 'Lỗi thay đổi mật khẩu.' });
        }
        // Get user actions for dashboard
        db.all('SELECT * FROM Action WHERE username = ?', [username], (err, actions) => {
            if (err) {
                actions = [];
            }
            res.render('dashboard', { username, success: 'Đổi mật khẩu thành công!', actions, layout: false });
        });
    });
});

app.get('/delete_account', loginRequired, (req, res) => {
    res.render('delete_account');
});

app.post('/delete_account', loginRequired, (req, res) => {
    const username = req.signedCookies.username;

    // Simplified - no password verification as requested
    db.run('DELETE FROM User WHERE username = ?', [username], (err) => {
        if (err) {
            return res.render('delete_account', { error: 'Lỗi xóa tài khoản.' });
        }
        res.clearCookie('username');
        res.render('index', { success: 'Tài khoản đã được xóa thành công.', layout: true });
    });

});

app.get('/flag', loginRequired, (req, res) => {
    const username = req.signedCookies.username;
    db.get('SELECT * FROM Action WHERE username = ? AND action_name = "banned"', [username], (err, row) => {
        if (err) {
            return res.render('flag', { layout: false });
        }
        if (row) {
            return res.render('flag', { message: 'Tài khoản của bạn đã bị cấm.', banned: row, layout: false });
        } else {
            return res.render('flag', { message: 'Chúc mừng! Bạn không bị cấm.', banned: false, flag: process.env.FLAG ?? "W1{test_flag}", layout: false });
        }
    });
});

// Initialize database and start server
initDb();

app.listen(PORT, () => {
    console.log(`Admin Tồi đang chạy tại http://localhost:${PORT}`);
});